CREATE TABLE `analysis_projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceUrl` text NOT NULL,
	`sourceTitle` text,
	`status` enum('processing','ready','failed') NOT NULL DEFAULT 'processing',
	`resultOrigin` enum('live','preview') NOT NULL DEFAULT 'preview',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `analysis_projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clip_candidates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`rank` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text NOT NULL,
	`hook` text NOT NULL,
	`rationale` text NOT NULL,
	`startSeconds` int NOT NULL,
	`endSeconds` int NOT NULL,
	`score` int NOT NULL,
	`status` enum('new','approved','dismissed') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clip_candidates_id` PRIMARY KEY(`id`)
);
