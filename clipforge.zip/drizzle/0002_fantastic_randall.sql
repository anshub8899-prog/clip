CREATE TABLE `rendered_clips` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchId` varchar(36) NOT NULL,
	`sourceVideoId` varchar(11) NOT NULL,
	`sourceTitle` varchar(512) NOT NULL,
	`title` varchar(180) NOT NULL,
	`startSeconds` int NOT NULL,
	`endSeconds` int NOT NULL,
	`objectKey` varchar(1024) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `rendered_clips_id` PRIMARY KEY(`id`)
);
