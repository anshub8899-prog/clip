import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const analysisProjects = mysqlTable("analysis_projects", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 36 }).unique(),
  sourceUrl: text("sourceUrl").notNull(),
  sourceTitle: text("sourceTitle"),
  durationSeconds: int("durationSeconds").notNull().default(0),
  status: mysqlEnum("status", ["processing", "ready", "failed"]).default("processing").notNull(),
  resultOrigin: mysqlEnum("resultOrigin", ["live", "preview"]).default("preview").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const clipCandidates = mysqlTable("clip_candidates", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  candidateId: varchar("candidateId", { length: 36 }),
  rank: int("rank").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description").notNull(),
  hook: text("hook").notNull(),
  rationale: text("rationale").notNull(),
  startSeconds: int("startSeconds").notNull(),
  endSeconds: int("endSeconds").notNull(),
  score: int("score").notNull(),
  status: mysqlEnum("status", ["new", "approved", "dismissed"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const renderedClips = mysqlTable("rendered_clips", {
  id: int("id").autoincrement().primaryKey(),
  batchId: varchar("batchId", { length: 36 }).notNull(),
  sourceVideoId: varchar("sourceVideoId", { length: 11 }).notNull(),
  sourceTitle: varchar("sourceTitle", { length: 512 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  startSeconds: int("startSeconds").notNull(),
  endSeconds: int("endSeconds").notNull(),
  objectKey: varchar("objectKey", { length: 1024 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type AnalysisProject = typeof analysisProjects.$inferSelect;
export type ClipCandidate = typeof clipCandidates.$inferSelect;
export type RenderedClipRecord = typeof renderedClips.$inferInsert;
