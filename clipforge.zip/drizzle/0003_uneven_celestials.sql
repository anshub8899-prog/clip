ALTER TABLE `analysis_projects` ADD `publicId` varchar(36);--> statement-breakpoint
ALTER TABLE `analysis_projects` ADD `durationSeconds` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `clip_candidates` ADD `candidateId` varchar(36);--> statement-breakpoint
ALTER TABLE `analysis_projects` ADD CONSTRAINT `analysis_projects_publicId_unique` UNIQUE(`publicId`);