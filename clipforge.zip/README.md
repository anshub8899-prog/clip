# ClipForge AI Shorts Editor

ClipForge finds source-grounded moments in public YouTube videos and turns reviewed moments into individual vertical MP4 clips. The Shorts gallery contains only cut video files—not the uploaded full source or an edit decision list.

## Workflow

1. Enter a public YouTube link. ClipForge checks available captions and accepts an optional timestamped transcript; when captions are unavailable, it attempts managed direct-video analysis. It does not invent moments when source media cannot be accessed.
2. Review the source and ranked moments. Approve clips to export or dismiss unwanted suggestions. Review decisions are saved server-side against an unguessable analysis and candidate ID.
3. Upload the matching source video file you own or are authorized to edit and confirm that authorization. The server resolves the YouTube source from the saved analysis, accepts videos up to 200 MB, probes the uploaded media with `ffprobe`, requires a known source duration, and rejects a duration difference greater than three seconds.
4. The server loads the canonical timestamps and titles from persisted approved candidates; browser-supplied cut times or a different analysis ID are not trusted. FFmpeg cuts each approved moment into a separate MP4, center-crops it to exactly 1080×1920 (9:16), and preserves source audio when present. The full source video is never returned as a clip.
5. Generated MP4s are stored in durable project storage at stable `/manus-storage/...` paths. Clip metadata is indexed in the project database; the browser retains its 24 most recent result references through refreshes. If metadata indexing fails after rendering, the app still returns playable/downloadable clips and displays an explicit warning. Uploaded sources and temporary render files are deleted when processing ends.

**Source identity limitation:** ClipForge binds each render to the saved YouTube analysis and checks the uploaded file's duration, but it does not download YouTube media or compare the uploaded file's content fingerprint. The user must ensure the uploaded file is the matching source and confirm they have editing rights.

The Shorts output preserves original audio. A selected music direction is retained as an edit note; ClipForge does not mix an additional music track.

## AI usage and errors

ClipForge uses the project's managed LLM service. A 412 usage-exhausted response is treated as non-transient and is not retried repeatedly. The UI explains that analysis is unavailable until workspace model usage is restored or becomes available again. Source code cannot restore account/workspace quota, and the app does not bypass it.

## Development

- `pnpm dev` starts the managed Express/tRPC and Vite app on the configured `PORT` (default 3000).
- `pnpm check` type-checks the client and server.
- `pnpm test` runs regression tests.
- `pnpm build` builds the production client and server.
- `pnpm db:migrate` applies checked-in additive database migrations.

FFmpeg and ffprobe are installed by the production `Dockerfile`. The managed database stores analysis, review decisions, and generated-clip metadata. Managed project helpers provide LLM and object-storage access; no separate model-provider or storage credential is needed.
