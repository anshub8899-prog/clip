import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("./env", () => ({
  ENV: {
    get forgeApiUrl() { return "https://api.example.test"; },
    get forgeApiKey() { return "test-key"; },
  },
}));

import { invokeLLM } from "./llm";

afterEach(() => vi.unstubAllGlobals());

describe("managed LLM retries", () => {
  it("does not retry an exhausted-usage 412 precondition response", async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response(
      JSON.stringify({ code: 9, message: "your account has hit a usage exhausted" }),
      { status: 412, statusText: "Precondition Failed" },
    ));
    vi.stubGlobal("fetch", fetchMock);

    await expect(invokeLLM({ messages: [{ role: "user", content: "Find strong moments." }] }))
      .rejects.toThrow(/412 Precondition Failed/);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
