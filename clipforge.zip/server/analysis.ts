import { randomUUID } from "node:crypto";
import { invokeLLM, listLLMModels } from "./_core/llm";
import { getDb } from "./db";
import { analysisProjects, clipCandidates } from "../drizzle/schema";

export type ClipStatus = "new" | "approved" | "dismissed";
export type MusicMood = "none" | "cinematic" | "upbeat" | "lofi" | "energetic" | "motivational";

export type ClipOpportunity = {
  id: string;
  rank: number;
  title: string;
  description: string;
  hook: string;
  rationale: string;
  editNotes: string;
  startSeconds: number;
  endSeconds: number;
  score: number;
  status: ClipStatus;
};

export type AnalysisResult = {
  projectId: string;
  sourceUrl: string;
  sourceVideoId: string;
  sourceTitle: string;
  durationSeconds: number;
  resultOrigin: "live";
  transcriptSource: "youtube-captions" | "user-provided" | "audio-transcription" | "direct-video-analysis";
  editDescription: string;
  musicMood: MusicMood;
  candidates: ClipOpportunity[];
};

type Caption = { start: number; end: number; text: string };

const candidateSchema = {
  type: "object",
  additionalProperties: false,
  required: ["title", "description", "hook", "rationale", "editNotes", "startSeconds", "endSeconds", "score"],
  properties: {
    title: { type: "string" },
    description: { type: "string" },
    hook: { type: "string" },
    rationale: { type: "string" },
    editNotes: { type: "string" },
    startSeconds: { type: "integer", minimum: 0 },
    endSeconds: { type: "integer", minimum: 1 },
    score: { type: "integer", minimum: 0, maximum: 100 },
  },
} as const;

const outputSchema = {
  name: "clip_opportunities",
  strict: true,
  schema: {
    type: "object",
    additionalProperties: false,
    required: ["sourceTitle", "candidates"],
    properties: {
      sourceTitle: { type: "string" },
      candidates: { type: "array", minItems: 1, maxItems: 6, items: candidateSchema },
    },
  },
} as const;

const directVideoSchema = {
  name: "direct_video_clip_opportunities",
  strict: true,
  schema: {
    type: "object",
    additionalProperties: false,
    required: ["accessible", "sourceTitle", "durationSeconds", "candidates"],
    properties: {
      accessible: { type: "boolean" },
      sourceTitle: { type: "string" },
      durationSeconds: { type: "integer", minimum: 1 },
      candidates: { type: "array", minItems: 0, maxItems: 6, items: candidateSchema },
    },
  },
} as const;

const YOUTUBE_HOSTS = new Set(["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtube-nocookie.com"]);

export function extractYouTubeVideoId(value: string): string | null {
  try {
    const url = new URL(value.trim());
    if (!YOUTUBE_HOSTS.has(url.hostname.toLowerCase())) return null;
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    let id = "";
    if (url.hostname.toLowerCase().includes("youtu.be")) id = url.pathname.split("/").filter(Boolean)[0] ?? "";
    else if (url.pathname === "/watch") id = url.searchParams.get("v") ?? "";
    else if (/^\/(shorts|embed|live)\//.test(url.pathname)) id = url.pathname.split("/")[2] ?? "";
    return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
  } catch {
    return null;
  }
}

export function validateVideoUrl(value: string) {
  return extractYouTubeVideoId(value) !== null;
}

function decodeEntities(text: string) {
  return text
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, value: string) => String.fromCodePoint(Number(value)));
}

function extractJsonAfter(html: string, marker: string): Record<string, any> | null {
  const markerIndex = html.indexOf(marker);
  if (markerIndex < 0) return null;
  const start = html.indexOf("{", markerIndex + marker.length);
  if (start < 0) return null;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < html.length; index++) {
    const char = html[index];
    if (inString) {
      if (escaped) escaped = false;
      else if (char === "\\") escaped = true;
      else if (char === '"') inString = false;
      continue;
    }
    if (char === '"') inString = true;
    else if (char === "{") depth++;
    else if (char === "}" && --depth === 0) {
      try {
        return JSON.parse(html.slice(start, index + 1)) as Record<string, any>;
      } catch {
        return null;
      }
    }
  }
  return null;
}

function parseXmlCaptions(xml: string): Caption[] {
  const captions: Caption[] = [];
  for (const match of xml.matchAll(/<text\b[^>]*start="([\d.]+)"[^>]*dur="([\d.]+)"[^>]*>([\s\S]*?)<\/text>/g)) {
    const text = decodeEntities(match[3].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ")).trim();
    if (!text) continue;
    const start = Number(match[1]);
    captions.push({ start, end: start + Number(match[2]), text });
  }
  return captions;
}

async function getCaptions(videoId: string, includeCaptions = true): Promise<{ captions: Caption[]; durationSeconds: number; title: string } | null> {
  try {
    const response = await fetch(`https://www.youtube.com/watch?v=${videoId}&hl=en`, {
      headers: { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36" },
      signal: AbortSignal.timeout(15_000),
    });
    if (!response.ok) return null;
    const html = await response.text();
    if (html.length > 18_000_000) return null;
    const player = extractJsonAfter(html, "ytInitialPlayerResponse = ") ?? {};
    const detail = player.videoDetails ?? {};
    const title = String(detail.title ?? "").trim();
    const durationSeconds = Number(detail.lengthSeconds ?? 0);
    if (!includeCaptions) return { captions: [], durationSeconds, title };
    const tracks: Array<{ baseUrl?: string; languageCode?: string; kind?: string }> =
      player.captions?.playerCaptionsTracklistRenderer?.captionTracks ?? [];
    const preferred = [...tracks].sort((a, b) => Number(a.kind === "asr") - Number(b.kind === "asr"));
    for (const track of preferred.slice(0, 3)) {
      if (!track.baseUrl) continue;
      const captionUrl = new URL(track.baseUrl);
      captionUrl.searchParams.set("fmt", "json3");
      const captionResponse = await fetch(captionUrl, { signal: AbortSignal.timeout(12_000) });
      if (!captionResponse.ok) continue;
      const body = await captionResponse.text();
      let captions: Caption[] = [];
      try {
        const data = JSON.parse(body) as { events?: Array<{ tStartMs?: number; dDurationMs?: number; segs?: Array<{ utf8?: string }> }> };
        captions = (data.events ?? []).flatMap(event => {
          const text = (event.segs ?? []).map(segment => segment.utf8 ?? "").join("").replace(/\s+/g, " ").trim();
          if (!text || event.tStartMs === undefined) return [];
          const start = event.tStartMs / 1000;
          return [{ start, end: start + (event.dDurationMs ?? 2000) / 1000, text }];
        });
      } catch {
        captions = parseXmlCaptions(body);
      }
      const usableTextLength = captions.map(caption => caption.text).join(" ").trim().length;
      if (usableTextLength > 0) return { captions, durationSeconds, title };
    }
    return { captions: [], durationSeconds, title };
  } catch (error) {
    console.warn("[Analysis] YouTube caption fetch failed:", error instanceof Error ? error.message : error);
    return null;
  }
}

function parseModelJson(content: string) {
  const cleaned = content.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end < start) throw new Error("The model returned no clip data.");
  return JSON.parse(cleaned.slice(start, end + 1)) as {
    sourceTitle?: string;
    durationSeconds?: number;
    accessible?: boolean;
    candidates?: Array<Omit<ClipOpportunity, "id" | "rank" | "status">>;
  };
}

type AnalysisArgs = {
  sourceUrl: string;
  videoId: string;
  editDescription: string;
  musicMood: MusicMood;
  clipCount: number;
  transcriptText: string;
  transcriptSource: AnalysisResult["transcriptSource"];
  durationSeconds: number;
  sourceTitle: string;
};

type DirectVideoArgs = Omit<AnalysisArgs, "transcriptText" | "transcriptSource">;

export function normalizeAnalysisError(error: unknown): Error {
  const message = error instanceof Error ? error.message : String(error);
  if (/usage\s*exhausted|exhausted\s+(?:the\s+)?(?:usage|quota)|quota\s+(?:is\s+)?(?:exhausted|depleted)|412\s+precondition/i.test(message)) {
    return new Error("ClipForge AI analysis is temporarily unavailable because this workspace has exhausted its model usage. No clip suggestions were created. Restore AI usage or try again later.");
  }
  return error instanceof Error ? error : new Error("ClipForge could not complete the analysis. Please try again.");
}

function assembleAnalysisResult(
  args: Omit<AnalysisArgs, "transcriptText">,
  parsed: ReturnType<typeof parseModelJson>,
): AnalysisResult {
  const resolvedDuration = args.durationSeconds || parsed.durationSeconds || 0;
  const sourceDuration = resolvedDuration || Number.MAX_SAFE_INTEGER;
  const candidates: Array<Omit<ClipOpportunity, "id" | "rank" | "status">> = [];
  for (const item of parsed.candidates ?? []) {
    if (
      Number.isFinite(item.startSeconds) && Number.isFinite(item.endSeconds) &&
      item.startSeconds >= 0 && item.endSeconds > item.startSeconds && item.endSeconds <= sourceDuration &&
      item.endSeconds - item.startSeconds >= 10 && item.endSeconds - item.startSeconds <= 180 &&
      !candidates.some(existing => item.startSeconds < existing.endSeconds && item.endSeconds > existing.startSeconds)
    ) candidates.push(item);
    if (candidates.length >= args.clipCount) break;
  }
  if (!candidates.length) {
    const evidenceName = args.transcriptSource === "direct-video-analysis" ? "video" : "transcript";
    throw new Error(`No grounded moments were found in the available ${evidenceName}. Try a longer source or a source with clearer speech.`);
  }
  return {
    projectId: randomUUID(),
    sourceUrl: args.sourceUrl,
    sourceVideoId: args.videoId,
    sourceTitle: parsed.sourceTitle?.trim() || args.sourceTitle || "YouTube source video",
    durationSeconds: resolvedDuration,
    resultOrigin: "live",
    transcriptSource: args.transcriptSource,
    editDescription: args.editDescription,
    musicMood: args.musicMood,
    candidates: candidates.map((item, index) => ({
      ...item,
      score: Math.max(0, Math.min(100, Math.round(item.score))),
      id: randomUUID(),
      rank: index + 1,
      status: "new" as const,
    })),
  };
}

function buildTranscript(captions: Caption[]) {
  return captions.map(caption => `[${Math.floor(caption.start)}s-${Math.ceil(caption.end)}s] ${caption.text}`).join("\n").slice(0, 42_000);
}

function transcriptTimecodes(text: string) {
  const seconds: number[] = [];
  for (const match of text.matchAll(/(?:^|\s|\[)(\d{1,2}:)?(\d{1,2}):(\d{2})(?:\]|\s|$)/gm)) {
    const hours = match[1] ? Number(match[1].slice(0, -1)) : 0;
    seconds.push(hours * 3600 + Number(match[2]) * 60 + Number(match[3]));
  }
  return seconds;
}

async function runGroundedAnalysis(args: AnalysisArgs): Promise<AnalysisResult> {
  const models = await listLLMModels();
  const available = models.data;
  const model = available.find(item => item.id.startsWith("gpt")) ?? available[0];
  if (!model) throw new Error("No analysis model is available right now. Please try again later.");
  const response = await invokeLLM({
    model: model.id,
    maxTokens: 5000,
    messages: [
      {
        role: "system",
        content: "You are ClipForge, an expert short-form video editor. Only recommend cuts that are supported by the supplied timestamped transcript. Never invent events, quotes, or timestamps. Find as many distinct, self-contained moments as the source supports, up to 6, prioritizing moments with a fast hook, enough context, and a payoff. Follow the requested editing brief; every editNotes value must describe practical choices for crop, pacing, captions, or sound. Respect the source duration and return only grounded cuts. Return valid JSON matching the schema.",
      },
      {
        role: "user",
        content: `Source title: ${args.sourceTitle || "YouTube video"}\nVideo duration: ${args.durationSeconds || "unknown"} seconds\nMaximum clip set: ${args.clipCount}\nUser edit description: ${args.editDescription || "Create clean, engaging vertical shorts with accurate captions and tight pacing."}\nMusic direction: ${args.musicMood}\nTranscript source: ${args.transcriptSource}\n\nTimestamped transcript:\n${args.transcriptText}\n\nFind as many non-overlapping moments as the timestamped transcript genuinely supports, up to ${args.clipCount}. Do not pad the list with weak or invented clips. Each segment should usually be 20-90 seconds; keep endSeconds greater than startSeconds and never exceed the known source duration. If the source duration is unknown, do not treat the last transcript timecode as the full video duration. Rank strongest first. Mention the requested music direction in concise edit notes, but do not claim audio has already been mixed.`,
      },
    ],
    responseFormat: { type: "json_schema", json_schema: outputSchema },
  });
  const content = response.choices?.[0]?.message?.content;
  if (typeof content !== "string" || !content.trim()) throw new Error("The analysis model returned no clip list. Please try again.");
  return assembleAnalysisResult(args, parseModelJson(content));
}

async function runDirectVideoAnalysis(args: DirectVideoArgs): Promise<AnalysisResult> {
  const models = await listLLMModels();
  const model = models.data.find(item => item.id === "gemini-3.8-flash");
  if (!model) throw new Error("Direct video analysis is temporarily unavailable. Please try again later.");
  const canonicalVideoUrl = `https://www.youtube.com/watch?v=${args.videoId}`;

  const response = await invokeLLM({
    model: model.id,
    maxTokens: 7000,
    messages: [
      {
        role: "system",
        content: "You are ClipForge, an expert short-form editor. Inspect the attached video and its audio directly, not just the URL or title. Find as many distinct, self-contained short-form moments as the source genuinely supports, up to 6, with a hook, context, and payoff. Use only moments you can directly observe in the video/audio. Return startSeconds and endSeconds as accurate integer seconds from the video timeline. If the actual media cannot be accessed or inspected, set accessible to false and return an empty candidates array; never guess or fabricate clip times. When accessible, return grounded non-overlapping candidates, 10-180 seconds each and within the actual video duration. Include the real source title and duration. Follow the requested editing brief and music direction; do not claim that edits or audio have already been rendered.",
      },
      {
        role: "user",
        content: [
          {
            type: "text",
            text: `Analyze the attached YouTube video itself. Canonical source URL: ${canonicalVideoUrl}\nKnown source duration: ${args.durationSeconds || "not available"} seconds\nMaximum clip set: ${args.clipCount}\nEdit description: ${args.editDescription || "Vertical 9:16 shorts, tight pacing, accurate captions, strongest hook first."}\nMusic direction: ${args.musicMood}\nInspect the actual video/audio and identify as many exact, non-overlapping cut windows as the source supports, up to ${args.clipCount}. Set accessible true only if you can inspect the media.`,
          },
          { type: "file_url", file_url: { url: canonicalVideoUrl, mime_type: "video/mp4" } },
        ],
      },
    ],
    responseFormat: { type: "json_schema", json_schema: directVideoSchema },
  });
  const content = response.choices?.[0]?.message?.content;
  if (typeof content !== "string" || !content.trim()) throw new Error("Direct video analysis returned no clip list. Please retry.");
  const parsed = parseModelJson(content);
  if (parsed.accessible !== true) {
    console.warn(`[Analysis] Direct video model ${model.id} could not confirm access to video ${args.videoId}`);
    throw new Error("ClipForge could not access this video's content. Check that the YouTube video is public and available, then retry.");
  }
  return assembleAnalysisResult({ ...args, transcriptSource: "direct-video-analysis" }, parsed);
}

async function persist(result: AnalysisResult) {
  const db = await getDb();
  if (!db) throw new Error("The project database is unavailable, so ClipForge could not save this analysis for review.");
  try {
    const projectInsert = await db.insert(analysisProjects).values({
      publicId: result.projectId,
      sourceUrl: result.sourceUrl,
      sourceTitle: result.sourceTitle,
      durationSeconds: result.durationSeconds,
      status: "ready",
      resultOrigin: result.resultOrigin,
    });
    const projectId = Number(projectInsert[0].insertId);
    if (!projectId) throw new Error("Analysis project insert returned no identifier.");
    await db.insert(clipCandidates).values(result.candidates.map(candidate => ({
      projectId,
      candidateId: candidate.id,
      rank: candidate.rank,
      title: candidate.title,
      description: candidate.description,
      hook: candidate.hook,
      rationale: candidate.rationale,
      startSeconds: candidate.startSeconds,
      endSeconds: candidate.endSeconds,
      score: candidate.score,
      status: candidate.status,
    })));
  } catch (error) {
    console.error("[Analysis] Failed to persist review state:", error instanceof Error ? error.message : error);
    throw new Error("ClipForge could not save the analysis for review. Please try again.");
  }
}

export async function analyzeVideo(input: {
  url: string;
  editDescription: string;
  musicMood: MusicMood;
  clipCount: number;
  transcript?: string;
}): Promise<AnalysisResult> {
  const sourceUrl = input.url.trim();
  const videoId = extractYouTubeVideoId(sourceUrl);
  if (!videoId) throw new Error("Use a public YouTube video link (youtube.com or youtu.be).");

  const manualTranscript = input.transcript?.trim() ?? "";
  const manualTimecodeSeconds = transcriptTimecodes(manualTranscript);
  if (manualTranscript && manualTimecodeSeconds.length < 4) {
    throw new Error("The pasted transcript needs timestamps (for example, [00:42] words spoken here) so the suggested clip times map back to the video.");
  }
  let imported: { captions: Caption[]; durationSeconds: number; title: string } | null = null;
  let transcriptSource: AnalysisResult["transcriptSource"] = "user-provided";
  let transcriptText = manualTranscript;
  let durationSeconds = 0;
  let sourceTitle = "";
  let directVideoFallback = false;

  imported = await getCaptions(videoId, !manualTranscript);
  sourceTitle = imported?.title ?? "";
  durationSeconds = imported?.durationSeconds ?? 0;

  if (!manualTranscript) {
    const captionTranscript = buildTranscript(imported?.captions ?? []);

    if (captionTranscript.trim().length >= 100) {
      transcriptText = captionTranscript;
      transcriptSource = "youtube-captions";
    } else {
      directVideoFallback = true;
    }
  }

  const analysisArgs = {
    sourceUrl,
    videoId,
    editDescription: input.editDescription.trim().slice(0, 1000),
    musicMood: input.musicMood,
    clipCount: input.clipCount,
    durationSeconds,
    sourceTitle,
  };
  let result: AnalysisResult;
  try {
    result = directVideoFallback
      ? await runDirectVideoAnalysis(analysisArgs)
      : await runGroundedAnalysis({
        ...analysisArgs,
        transcriptText,
        transcriptSource,
      });
  } catch (error) {
    throw normalizeAnalysisError(error);
  }
  await persist(result);
  return result;
}

export async function renderApprovedClips(result: AnalysisResult, clipIds: string[]) {
  const endpoint = process.env.CLIPFORGE_RENDER_API_URL;
  if (!endpoint) throw new Error("Video rendering is not configured yet. You can download the edit plan now, or connect a render provider with CLIPFORGE_RENDER_API_URL.");
  if (!validateVideoUrl(result.sourceUrl) || extractYouTubeVideoId(result.sourceUrl) !== result.sourceVideoId) {
    throw new Error("The render request source does not match the analyzed YouTube video.");
  }
  const providerUrl = new URL(endpoint);
  if (!["https:", "http:"].includes(providerUrl.protocol)) throw new Error("The render provider URL must use HTTP or HTTPS.");
  const requestedIds = new Set(clipIds);
  if (requestedIds.size !== clipIds.length) throw new Error("The render request contains duplicate clip IDs.");
  const selected = result.candidates.filter(candidate => requestedIds.has(candidate.id));
  if (!selected.length) throw new Error("Approve at least one clip before rendering.");
  if (selected.length !== requestedIds.size) throw new Error("The render request contains an unknown clip ID.");
  const response = await fetch(providerUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(process.env.CLIPFORGE_RENDER_API_KEY ? { Authorization: `Bearer ${process.env.CLIPFORGE_RENDER_API_KEY}` } : {}),
    },
    body: JSON.stringify({
      sourceUrl: result.sourceUrl,
      sourceVideoId: result.sourceVideoId,
      editDescription: result.editDescription,
      musicMood: result.musicMood,
      output: { aspectRatio: "9:16", captions: true },
      clips: selected.map(({ id, title, description, startSeconds, endSeconds, editNotes }) => ({ id, title, description, startSeconds, endSeconds, editNotes })),
    }),
    signal: AbortSignal.timeout(120_000),
  });
  if (!response.ok) throw new Error(`Render provider returned ${response.status}. Check its connection and try again.`);
  const payload = await response.json() as { jobId?: string; status?: string; clips?: Array<{ id?: string; url?: string }> };
  const clips = (payload.clips ?? []).flatMap(clip => {
    if (!clip.url) return [];
    try {
      const url = new URL(clip.url);
      return url.protocol === "https:" ? [{ id: clip.id ?? "rendered-clip", url: url.toString() }] : [];
    } catch {
      return [];
    }
  });
  return { jobId: payload.jobId, status: payload.status, clips };
}
