import { and, eq, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { analysisProjects, clipCandidates, InsertUser, RenderedClipRecord, renderedClips, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    throw new Error("Database is not available");
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function saveRenderedClips(records: RenderedClipRecord[]) {
  if (!records.length) return;
  const db = await getDb();
  if (!db) throw new Error("The project database is unavailable.");
  await db.insert(renderedClips).values(records);
}

export async function updateCandidateStatus(projectPublicId: string, candidatePublicId: string, status: "approved" | "dismissed") {
  const db = await getDb();
  if (!db) throw new Error("The project database is unavailable. Candidate review could not be saved.");
  const [project] = await db.select({ id: analysisProjects.id }).from(analysisProjects).where(and(
    eq(analysisProjects.publicId, projectPublicId),
    eq(analysisProjects.status, "ready"),
    eq(analysisProjects.resultOrigin, "live"),
  )).limit(1);
  if (!project) return false;
  const [candidate] = await db.select({ id: clipCandidates.id }).from(clipCandidates).where(and(
    eq(clipCandidates.projectId, project.id),
    eq(clipCandidates.candidateId, candidatePublicId),
  )).limit(1);
  if (!candidate) return false;
  await db.update(clipCandidates).set({ status }).where(eq(clipCandidates.id, candidate.id));
  return true;
}

export async function getApprovedAnalysisCuts(projectPublicId: string, candidatePublicIds: string[]) {
  const db = await getDb();
  if (!db) throw new Error("The project database is unavailable. Shorts rendering cannot verify this analysis.");
  const [project] = await db.select().from(analysisProjects).where(and(
    eq(analysisProjects.publicId, projectPublicId),
    eq(analysisProjects.status, "ready"),
    eq(analysisProjects.resultOrigin, "live"),
  )).limit(1);
  if (!project || !project.publicId) throw new Error("This analysis could not be found. Analyze the YouTube source again before rendering.");
  const candidates = await db.select().from(clipCandidates).where(and(
    eq(clipCandidates.projectId, project.id),
    inArray(clipCandidates.candidateId, candidatePublicIds),
    eq(clipCandidates.status, "approved"),
  ));
  if (candidates.length !== candidatePublicIds.length || candidates.some(candidate => !candidate.candidateId)) {
    throw new Error("One or more requested moments were not approved for this analysis. Review and approve the clips again.");
  }
  return {
    project,
    candidates: candidates.map(candidate => ({
      id: candidate.candidateId!,
      title: candidate.title,
      startSeconds: candidate.startSeconds,
      endSeconds: candidate.endSeconds,
    })),
  };
}
