import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(),
  listLLMModels: vi.fn(),
}));
const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("./db", () => ({ getDb: mockGetDb }));

import { invokeLLM, listLLMModels } from "./_core/llm";
import { analyzeVideo, normalizeAnalysisError, validateVideoUrl } from "./analysis";

const clips = [
  { title: "The sharp opening", description: "A complete point with a quick payoff.", hook: "Start on the question.", rationale: "The transcript sets up a clear payoff.", editNotes: "Vertical crop; keep the first sentence as the caption hook.", startSeconds: 10, endSeconds: 40, score: 96 },
  { title: "A useful rule", description: "A short standalone lesson.", hook: "Lead on the rule.", rationale: "The example explains it clearly.", editNotes: "Trim the pause; use readable captions.", startSeconds: 50, endSeconds: 80, score: 91 },
  { title: "The reversal", description: "A surprising turn with enough context.", hook: "Open on the contrast.", rationale: "The point resolves within the segment.", editNotes: "Use a quick punch-in on the reveal.", startSeconds: 90, endSeconds: 120, score: 88 },
  { title: "The takeaway", description: "A practical ending worth saving.", hook: "Start with the takeaway.", rationale: "The source gives a self-contained summary.", editNotes: "Hold the final caption for one beat.", startSeconds: 130, endSeconds: 160, score: 85 },
];

const transcript = [
  "[00:00] The opening statement introduces the idea and asks a sharp question.",
  "[00:45] The speaker gives a useful rule and an example with clear context.",
  "[01:30] The story turns in an unexpected direction and explains why.",
  "[02:20] A practical lesson ties the point together for viewers.",
  "[03:15] The closing takeaway summarizes the idea and invites a response.",
].join("\n");

beforeEach(() => {
  vi.clearAllMocks();
  mockGetDb.mockResolvedValue({
    insert: vi.fn(() => ({ values: vi.fn().mockResolvedValue([{ insertId: 1 }]) })),
  });
  vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(
    '<script>ytInitialPlayerResponse = {"videoDetails":{"title":"A source video","lengthSeconds":"200"}};</script>',
    { status: 200 },
  )));
  vi.mocked(listLLMModels).mockResolvedValue({ data: [{ id: "gpt-test", status: "available" }] } as never);
  vi.mocked(invokeLLM).mockResolvedValue({
    choices: [{ message: { content: JSON.stringify({ sourceTitle: "A source video", candidates: clips }) } }],
  } as never);
});

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("ClipForge source-grounded analysis", () => {
  it("turns exhausted LLM usage into an actionable error without exposing the raw 412 response", () => {
    const error = normalizeAnalysisError(new Error('LLM invoke failed: 412 Precondition Failed – {"code":9,"message":"your account has hit a usage exhausted"}'));
    expect(error.message).toContain("workspace has exhausted its model usage");
    expect(error.message).toContain("No clip suggestions were created");
    expect(error.message).not.toContain("412 Precondition Failed");
  });

  it("accepts YouTube video links and rejects lookalike hosts or malformed IDs", () => {
    expect(validateVideoUrl("https://youtu.be/M7lc1UVf-VE")).toBe(true);
    expect(validateVideoUrl("https://www.youtube.com/watch?v=M7lc1UVf-VE")).toBe(true);
    expect(validateVideoUrl("https://youtube.com.evil.example/watch?v=M7lc1UVf-VE")).toBe(false);
    expect(validateVideoUrl("https://youtube.com/watch?v=short")).toBe(false);
  });

  it("requires timestamped user transcripts rather than guessing cut times", async () => {
    await expect(analyzeVideo({
      url: "https://youtu.be/M7lc1UVf-VE",
      editDescription: "Fast, readable vertical captions",
      musicMood: "upbeat",
      clipCount: 4,
      transcript: "This is a transcript with words but no timecodes.",
    })).rejects.toThrow(/needs timestamps/);
    expect(invokeLLM).not.toHaveBeenCalled();
  });

  it("forms shorts from the video itself when captions are missing and no transcript is supplied", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(
      '<script>ytInitialPlayerResponse = {"videoDetails":{"title":"No captions","lengthSeconds":"200"}};</script>',
      { status: 200 },
    )));
    vi.mocked(listLLMModels).mockResolvedValue({ data: [{ id: "gemini-3.8-flash", status: "available" }] } as never);
    vi.mocked(invokeLLM).mockResolvedValue({
      choices: [{ message: { content: JSON.stringify({ accessible: true, sourceTitle: "No captions", durationSeconds: 200, candidates: clips }) } }],
    } as never);

    const result = await analyzeVideo({
      url: "https://youtu.be/M7lc1UVf-VE",
      editDescription: "Fast, readable vertical captions",
      musicMood: "upbeat",
      clipCount: 4,
    });

    expect(result.transcriptSource).toBe("direct-video-analysis");
    expect(result.candidates).toHaveLength(4);
    expect(vi.mocked(invokeLLM).mock.calls[0][0].model).toBe("gemini-3.8-flash");
    expect(JSON.stringify(vi.mocked(invokeLLM).mock.calls[0][0].messages)).toContain('"mime_type":"video/mp4"');
    expect(JSON.stringify(vi.mocked(invokeLLM).mock.calls[0][0].messages)).toContain("youtube.com/watch?v=M7lc1UVf-VE");
  });

  it("does not fabricate cut candidates when direct video media is inaccessible", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(
      '<script>ytInitialPlayerResponse = {"videoDetails":{"title":"Private video","lengthSeconds":"200"}};</script>',
      { status: 200 },
    )));
    vi.mocked(listLLMModels).mockResolvedValue({ data: [{ id: "gemini-3.8-flash", status: "available" }] } as never);
    vi.mocked(invokeLLM).mockResolvedValue({
      choices: [{ message: { content: JSON.stringify({ accessible: false, sourceTitle: "Private video", durationSeconds: 200, candidates: [] }) } }],
    } as never);

    await expect(analyzeVideo({
      url: "https://youtu.be/M7lc1UVf-VE",
      editDescription: "Fast, readable vertical captions",
      musicMood: "upbeat",
      clipCount: 4,
    })).rejects.toThrow(/could not access this video's content/);
  });

  it("forms short candidates from usable YouTube captions with fewer than eight events", async () => {
    const captionEvents = [
      "The opening statement introduces the main idea and asks a sharp question for viewers.",
      "The speaker gives a useful rule and an example with clear practical context.",
      "The story turns in an unexpected direction and explains why the change matters.",
      "A practical lesson ties the point together and provides a clear takeaway.",
    ].map((text, index) => ({
      tStartMs: index * 45_000,
      dDurationMs: 30_000,
      segs: [{ utf8: text }],
    }));
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      if (String(input).includes("timedtext")) {
        return new Response(JSON.stringify({ events: captionEvents }), { status: 200 });
      }
      return new Response(
        '<script>ytInitialPlayerResponse = {"videoDetails":{"title":"Captioned source","lengthSeconds":"200"},"captions":{"playerCaptionsTracklistRenderer":{"captionTracks":[{"baseUrl":"https://www.youtube.com/api/timedtext?v=M7lc1UVf-VE","languageCode":"en"}]}}};</script>',
        { status: 200 },
      );
    });
    vi.stubGlobal("fetch", fetchMock);

    const result = await analyzeVideo({
      url: "https://youtu.be/M7lc1UVf-VE",
      editDescription: "Fast, readable vertical captions",
      musicMood: "upbeat",
      clipCount: 4,
    });

    expect(result.transcriptSource).toBe("youtube-captions");
    expect(result.candidates).toHaveLength(4);
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("passes the user brief and music direction to the model and returns four valid distinct cut ranges", async () => {
    const result = await analyzeVideo({
      url: "https://youtu.be/M7lc1UVf-VE",
      editDescription: "Punchy vertical edits with burned-in captions",
      musicMood: "energetic",
      clipCount: 4,
      transcript,
    });

    expect(result.candidates).toHaveLength(4);
    expect(result.candidates.map(clip => [clip.startSeconds, clip.endSeconds])).toEqual([
      [10, 40], [50, 80], [90, 120], [130, 160],
    ]);
    expect(result.transcriptSource).toBe("user-provided");
    expect(result.musicMood).toBe("energetic");
    expect(result.candidates.every(clip => clip.status === "new")).toBe(true);
    const request = vi.mocked(invokeLLM).mock.calls[0][0];
    const modelPrompt = JSON.stringify(request.messages);
    expect(modelPrompt).toContain("Maximum clip set: 4");
    expect(modelPrompt).toContain("Punchy vertical edits with burned-in captions");
    expect(modelPrompt).toContain("energetic");
  });

  it("uses verified video metadata instead of treating the final transcript timecode as source duration", async () => {
    vi.mocked(invokeLLM).mockResolvedValue({
      choices: [{ message: { content: JSON.stringify({
        sourceTitle: "A source video",
        candidates: [...clips.slice(0, 3), { ...clips[3], startSeconds: 165, endSeconds: 200 }],
      }) } }],
    } as never);

    const result = await analyzeVideo({
      url: "https://youtu.be/M7lc1UVf-VE",
      editDescription: "Fast, readable vertical captions",
      musicMood: "upbeat",
      clipCount: 4,
      transcript,
    });

    expect(result.durationSeconds).toBe(200);
    expect(result.candidates[3].endSeconds).toBe(200);
  });

  it("filters candidate times that exceed a known YouTube duration", async () => {
    const captionEvents = [
      "The opening introduces the topic and gives a clear hook for viewers.",
      "A useful rule is explained with a practical example and context.",
      "The story changes direction and resolves its central question.",
      "A final takeaway summarizes the key lesson in a memorable way.",
    ].map((text, index) => ({ tStartMs: index * 45_000, dDurationMs: 30_000, segs: [{ utf8: text }] }));
    vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL) => {
      if (String(input).includes("timedtext")) {
        return new Response(JSON.stringify({ events: captionEvents }), { status: 200 });
      }
      return new Response(
        '<script>ytInitialPlayerResponse = {"videoDetails":{"title":"Bounded source","lengthSeconds":"200"},"captions":{"playerCaptionsTracklistRenderer":{"captionTracks":[{"baseUrl":"https://www.youtube.com/api/timedtext?v=M7lc1UVf-VE","languageCode":"en"}]}}};</script>',
        { status: 200 },
      );
    }));
    vi.mocked(invokeLLM).mockResolvedValue({
      choices: [{ message: { content: JSON.stringify({
        sourceTitle: "Bounded source",
        candidates: [...clips.slice(0, 3), { ...clips[3], startSeconds: 180, endSeconds: 220 }],
      }) } }],
    } as never);

    const result = await analyzeVideo({
      url: "https://youtu.be/M7lc1UVf-VE",
      editDescription: "Fast, readable vertical captions",
      musicMood: "upbeat",
      clipCount: 4,
    });
    expect(result.candidates).toHaveLength(3);
  });

  it("returns all usable clips after filtering overlaps and invalid timestamps", async () => {
    vi.mocked(invokeLLM).mockResolvedValue({
      choices: [{ message: { content: JSON.stringify({
        sourceTitle: "A source video",
        candidates: [
          ...clips.slice(0, 3),
          { ...clips[3], startSeconds: 150, endSeconds: 150 },
          { ...clips[3], startSeconds: 20, endSeconds: 35 },
        ],
      }) } }],
    } as never);
    const result = await analyzeVideo({
      url: "https://youtu.be/M7lc1UVf-VE",
      editDescription: "Fast, readable vertical captions",
      musicMood: "lofi",
      clipCount: 4,
      transcript,
    });
    expect(result.candidates).toHaveLength(3);
  });
});
