import { createServer, type Server } from "node:http";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import express from "express";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

const execFileAsync = promisify(execFile);
const mockStoragePut = vi.hoisted(() => vi.fn());
const mockSaveRenderedClips = vi.hoisted(() => vi.fn());
const mockGetApprovedAnalysisCuts = vi.hoisted(() => vi.fn());

vi.mock("./storage", () => ({ storagePut: mockStoragePut }));
vi.mock("./db", () => ({ getApprovedAnalysisCuts: mockGetApprovedAnalysisCuts, saveRenderedClips: mockSaveRenderedClips }));

import { shortsRouter } from "./shorts";

let workDir = "";
let sourcePath = "";
let outputPath = "";
let server: Server | undefined;
let baseUrl = "";
const projectId = "8c6f22c4-e16f-4e4d-9d17-f930324a2e29";
const candidateId = "a3a8fc1a-4a96-46d6-a35a-28b6f3bd8be2";

async function makeForm() {
  const form = new FormData();
  form.append("sourceVideo", new Blob([new Uint8Array(await readFile(sourcePath))], { type: "video/mp4" }), "source.mp4");
  form.append("rightsConfirmed", "true");
  form.append("projectId", projectId);
  form.append("candidateIds", JSON.stringify([candidateId]));
  return form;
}

describe("authorized Shorts render endpoint", () => {
  beforeAll(async () => {
    workDir = await mkdtemp(path.join(tmpdir(), "clipforge-render-test-"));
    sourcePath = path.join(workDir, "source.mp4");
    outputPath = path.join(workDir, "stored.mp4");
    mockStoragePut.mockImplementation(async (key: string, content: Buffer | Uint8Array | string) => {
      const bytes = typeof content === "string" ? Buffer.from(content) : Buffer.from(content);
      await writeFile(outputPath, bytes);
      return { key: `${key}_test`, url: `/manus-storage/${key}_test` };
    });
    mockSaveRenderedClips.mockResolvedValue(undefined);
    mockGetApprovedAnalysisCuts.mockResolvedValue({
      project: { sourceUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ", sourceTitle: "Authorized source test", durationSeconds: 12 },
      candidates: [{ id: candidateId, title: "Approved test moment", startSeconds: 1, endSeconds: 11 }],
    });

    await execFileAsync("ffmpeg", [
      "-hide_banner", "-loglevel", "error", "-y",
      "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=12",
      "-f", "lavfi", "-i", "sine=frequency=880:sample_rate=44100",
      "-t", "12", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
      "-c:a", "aac", sourcePath,
    ], { timeout: 30_000 });

    const app = express();
    app.use("/api/shorts", shortsRouter);
    server = createServer(app);
    await new Promise<void>((resolve, reject) => {
      server!.once("error", reject);
      server!.listen(0, "127.0.0.1", resolve);
    });
    const address = server.address();
    if (!address || typeof address === "string") throw new Error("Test server did not bind a TCP port.");
    baseUrl = `http://127.0.0.1:${address.port}`;
  }, 60_000);

  afterAll(async () => {
    if (server) await new Promise<void>(resolve => server!.close(() => resolve()));
    if (workDir) await rm(workDir, { recursive: true, force: true });
  });

  it("cuts only server-approved moments and stores a vertical MP4 with source audio", async () => {
    const form = await makeForm();
    const response = await fetch(`${baseUrl}/api/shorts/render`, { method: "POST", body: form });
    const result = await response.json() as { aspectRatio?: string; width?: number; height?: number; metadataIndexed?: boolean; clips?: Array<{ url: string; downloadUrl: string }> };
    expect(response.status).toBe(200);
    expect(result).toMatchObject({ aspectRatio: "9:16", width: 1080, height: 1920 });
    expect(result.metadataIndexed).toBe(true);
    expect(result.clips).toHaveLength(1);
    expect(result.clips?.[0].url).toMatch(/^\/manus-storage\//);
    expect(result.clips?.[0].downloadUrl).toBe(result.clips?.[0].url);
    expect(mockStoragePut).toHaveBeenCalledTimes(1);
    expect(mockGetApprovedAnalysisCuts).toHaveBeenCalledWith(projectId, [candidateId]);
    expect(mockSaveRenderedClips).toHaveBeenCalledWith([expect.objectContaining({ sourceVideoId: "dQw4w9WgXcQ", sourceTitle: "Authorized source test", startSeconds: 1, endSeconds: 11 })]);

    const { stdout } = await execFileAsync("ffprobe", [
      "-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration", "-of", "json", outputPath,
    ]);
    const media = JSON.parse(stdout) as { format?: { duration?: string }; streams?: Array<{ codec_type: string; width?: number; height?: number }> };
    const video = media.streams?.find(stream => stream.codec_type === "video");
    expect(video).toMatchObject({ width: 1080, height: 1920 });
    expect(media.streams?.some(stream => stream.codec_type === "audio")).toBe(true);
    expect(Number(media.format?.duration)).toBeGreaterThanOrEqual(9.9);
    expect(Number(media.format?.duration)).toBeLessThanOrEqual(10.2);
  }, 60_000);

  it("rejects unapproved candidate IDs before encoding or storing clips", async () => {
    mockGetApprovedAnalysisCuts.mockRejectedValueOnce(new Error("One or more requested moments were not approved for this analysis."));
    const storageCalls = mockStoragePut.mock.calls.length;
    const response = await fetch(`${baseUrl}/api/shorts/render`, { method: "POST", body: await makeForm() });
    const result = await response.json() as { error?: string };
    expect(response.status).toBe(400);
    expect(result.error).toMatch(/not approved/);
    expect(mockStoragePut).toHaveBeenCalledTimes(storageCalls);
  });

  it("blocks rendering when the stored analysis has no verified source duration", async () => {
    mockGetApprovedAnalysisCuts.mockResolvedValueOnce({
      project: { sourceUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ", sourceTitle: "Unknown duration", durationSeconds: 0 },
      candidates: [{ id: candidateId, title: "Approved test moment", startSeconds: 1, endSeconds: 11 }],
    });
    const storageCalls = mockStoragePut.mock.calls.length;
    const response = await fetch(`${baseUrl}/api/shorts/render`, { method: "POST", body: await makeForm() });
    const result = await response.json() as { error?: string };
    expect(response.status).toBe(400);
    expect(result.error).toMatch(/duration could not be verified/);
    expect(mockStoragePut).toHaveBeenCalledTimes(storageCalls);
  });

  it("returns the rendered videos with an explicit warning when metadata indexing fails", async () => {
    mockSaveRenderedClips.mockRejectedValueOnce(new Error("database temporarily unavailable"));
    const response = await fetch(`${baseUrl}/api/shorts/render`, { method: "POST", body: await makeForm() });
    const result = await response.json() as { metadataIndexed?: boolean; warning?: string; clips?: Array<{ url: string }> };
    expect(response.status).toBe(200);
    expect(result.metadataIndexed).toBe(false);
    expect(result.warning).toMatch(/history records/);
    expect(result.clips).toHaveLength(1);
    expect(result.clips?.[0].url).toMatch(/^\/manus-storage\//);
  }, 60_000);
});
