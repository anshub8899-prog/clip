import { execFile } from "node:child_process";
import { randomUUID } from "node:crypto";
import { mkdtemp, mkdir, readFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import express, { type Request, type Response } from "express";
import multer from "multer";
import { extractYouTubeVideoId } from "./analysis";
import { getApprovedAnalysisCuts, saveRenderedClips } from "./db";
import { storagePut } from "./storage";

const execFileAsync = promisify(execFile);
const MAX_UPLOAD_BYTES = 200 * 1024 * 1024;
const MAX_CLIPS = 6;
const MAX_RENDERED_CLIP_BYTES = 200 * 1024 * 1024;
const tempRoot = path.join(os.tmpdir(), "clipforge-shorts");

type ShortCut = {
  id: string;
  title: string;
  startSeconds: number;
  endSeconds: number;
};
export function validateShortCuts(value: unknown, sourceDuration: number): ShortCut[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > MAX_CLIPS) {
    throw new Error("Choose between one and eight approved moments to render.");
  }
  const cuts: ShortCut[] = [];
  for (const [index, raw] of value.entries()) {
    if (!raw || typeof raw !== "object") throw new Error(`Clip ${index + 1} has invalid cut data.`);
    const cut = raw as Record<string, unknown>;
    const id = typeof cut.id === "string" ? cut.id : "";
    const title = typeof cut.title === "string" ? cut.title.trim().slice(0, 160) : "";
    const startSeconds = Number(cut.startSeconds);
    const endSeconds = Number(cut.endSeconds);
    if (!id || id.length > 128 || !title || !Number.isInteger(startSeconds) || !Number.isInteger(endSeconds)) {
      throw new Error(`Clip ${index + 1} has invalid cut data.`);
    }
    const duration = endSeconds - startSeconds;
    if (startSeconds < 0 || duration < 10 || duration > 180 || endSeconds > sourceDuration) {
      throw new Error(`Clip ${index + 1} is outside the source video's supported cut range.`);
    }
    if (cuts.some(existing => startSeconds < existing.endSeconds && endSeconds > existing.startSeconds)) {
      throw new Error("The selected moments overlap. Review the cut list and try again.");
    }
    cuts.push({ id, title, startSeconds, endSeconds });
  }
  return cuts;
}

function parseCandidateIds(value: unknown): string[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > MAX_CLIPS) {
    throw new Error("Choose between one and eight approved moments to render.");
  }
  const ids = value.map(item => typeof item === "string" ? item : "");
  const isUuid = (id: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id);
  if (ids.some(id => !isUuid(id)) || new Set(ids).size !== ids.length) {
    throw new Error("The approved clip list is invalid. Review the analysis and try again.");
  }
  return ids;
}

async function probeVideo(filePath: string) {
  const { stdout } = await execFileAsync(process.env.FFPROBE_PATH || "ffprobe", [
    "-v", "error",
    "-show_entries", "format=duration:stream=codec_type",
    "-of", "json",
    filePath,
  ], { timeout: 30_000, maxBuffer: 2 * 1024 * 1024 });
  const details = JSON.parse(stdout) as { format?: { duration?: string }; streams?: Array<{ codec_type?: string }> };
  const duration = Number(details.format?.duration);
  if (!Number.isFinite(duration) || duration <= 0 || !details.streams?.some(stream => stream.codec_type === "video")) {
    throw new Error("The uploaded file does not contain a readable video stream.");
  }
  return duration;
}

async function encodeVerticalClip(sourcePath: string, outputPath: string, cut: ShortCut) {
  const videoFilter = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1";
  try {
    await execFileAsync(process.env.FFMPEG_PATH || "ffmpeg", [
      "-hide_banner", "-loglevel", "error", "-y",
      "-i", sourcePath,
      "-ss", String(cut.startSeconds),
      "-t", String(cut.endSeconds - cut.startSeconds),
      "-map", "0:v:0",
      "-map", "0:a?",
      "-vf", videoFilter,
      "-c:v", "libx264",
      "-preset", "veryfast",
      "-crf", "23",
      "-c:a", "aac",
      "-b:a", "128k",
      "-movflags", "+faststart",
      "-max_muxing_queue_size", "1024",
      outputPath,
    ], { timeout: 20 * 60 * 1000, maxBuffer: 8 * 1024 * 1024 });
  } catch (error) {
    const detail = error instanceof Error ? error.message.slice(0, 1200) : String(error).slice(0, 1200);
    console.error(`[Shorts] FFmpeg failed for ${cut.id}: ${detail}`);
    throw new Error(`Clip “${cut.title}” could not be encoded. Please try another source file.`);
  }
}

function jsonError(res: Response, status: number, message: string) {
  if (!res.headersSent) res.status(status).json({ error: message });
}

export const shortsRouter = express.Router();

shortsRouter.post("/render", (req: Request, res: Response) => {
  void mkdir(tempRoot, { recursive: true }).then(async () => {
    const workDirectory = await mkdtemp(path.join(tempRoot, "upload-"));
    const upload = multer({
      storage: multer.diskStorage({
        destination: (_request, _file, callback) => callback(null, workDirectory),
        filename: (_request, _file, callback) => callback(null, "source-video"),
      }),
      limits: { fileSize: MAX_UPLOAD_BYTES, files: 1, fields: 3 },
      fileFilter: (_request, file, callback) => {
        if (!file.mimetype.toLowerCase().startsWith("video/")) {
          callback(new Error("Upload a video file (MP4, MOV, WebM, or another supported video format)."));
          return;
        }
        callback(null, true);
      },
    }).single("sourceVideo");

    upload(req, res, error => {
      if (error) {
        void rm(workDirectory, { recursive: true, force: true });
        const tooLarge = error instanceof multer.MulterError && error.code === "LIMIT_FILE_SIZE";
        jsonError(res, tooLarge ? 413 : 400, tooLarge ? "The source video exceeds the 200 MB upload limit." : error.message || "The video upload could not be read.");
        return;
      }
      void processUpload(req, res, workDirectory);
    });
  }).catch(error => {
    console.error("[Shorts] Could not create temporary upload directory:", error);
    jsonError(res, 500, "Shorts rendering is temporarily unavailable. Please try again later.");
  });
});

async function processUpload(req: Request, res: Response, workDirectory: string) {
  try {
    const file = req.file;
    if (!file) throw new Error("Choose the source video file you own or are authorized to edit.");
    if (req.body.rightsConfirmed !== "true") throw new Error("Confirm that you own or are authorized to edit this source video before rendering.");
    const projectPublicId = String(req.body.projectId ?? "").trim();
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(projectPublicId)) {
      throw new Error("The analysis reference is invalid. Analyze the source again and retry.");
    }
    let rawCandidateIds: unknown;
    try {
      rawCandidateIds = JSON.parse(String(req.body.candidateIds ?? ""));
    } catch {
      throw new Error("The approved clip list could not be read. Analyze the source again and retry.");
    }
    const candidateIds = parseCandidateIds(rawCandidateIds);
    const authorization = await getApprovedAnalysisCuts(projectPublicId, candidateIds);
    const sourceVideoId = extractYouTubeVideoId(authorization.project.sourceUrl);
    if (!sourceVideoId) throw new Error("The saved analysis does not contain a valid YouTube source. Analyze the source again.");
    const sourceTitle = authorization.project.sourceTitle?.trim().slice(0, 512) || "YouTube source video";
    const expectedDuration = authorization.project.durationSeconds;
    if (!Number.isFinite(expectedDuration) || expectedDuration <= 0) {
      throw new Error("The source duration could not be verified, so rendering is disabled. Analyze a link with available video details and retry.");
    }
    const actualDuration = await probeVideo(file.path);
    if (Math.abs(actualDuration - expectedDuration) > 3) {
      throw new Error(`This file is ${actualDuration.toFixed(1)} seconds long, which differs from the analyzed source by more than three seconds. Upload the matching source video.`);
    }
    const cuts = validateShortCuts(authorization.candidates, actualDuration);
    const jobId = randomUUID();
    const clips: Array<{ id: string; title: string; startSeconds: number; endSeconds: number; url: string; downloadUrl: string }> = [];
    const records: Array<{ batchId: string; sourceVideoId: string; sourceTitle: string; title: string; startSeconds: number; endSeconds: number; objectKey: string }> = [];

    for (const [index, cut] of cuts.entries()) {
      const clipKey = `clip-${String(index + 1).padStart(2, "0")}`;
      const outputPath = path.join(workDirectory, `${clipKey}.mp4`);
      await encodeVerticalClip(file.path, outputPath, cut);
      const content = await readFile(outputPath);
      if (content.byteLength > MAX_RENDERED_CLIP_BYTES) {
        throw new Error(`Clip “${cut.title}” is too large to store. Reduce the clip duration or use a smaller source file.`);
      }
      const asset = await storagePut(`clipforge/shorts/${jobId}/${clipKey}.mp4`, content, "video/mp4");
      clips.push({ id: cut.id, title: cut.title, startSeconds: cut.startSeconds, endSeconds: cut.endSeconds, url: asset.url, downloadUrl: asset.url });
      records.push({ batchId: jobId, sourceVideoId, sourceTitle, title: cut.title, startSeconds: cut.startSeconds, endSeconds: cut.endSeconds, objectKey: asset.key });
    }

    let metadataIndexed = true;
    try {
      await saveRenderedClips(records);
    } catch {
      console.warn("[Shorts] Clip metadata could not be indexed; the durable MP4 files are still available.");
      metadataIndexed = false;
    }
    res.json({ status: "complete", jobId, storage: "durable", metadataIndexed, ...(metadataIndexed ? {} : { warning: "The video files were saved, but ClipForge could not write their history records. Keep or download these clip links while the issue is resolved." }), aspectRatio: "9:16", width: 1080, height: 1920, clips });
  } catch (error) {
    const message = error instanceof Error ? error.message : "The source video could not be rendered.";
    const storageError = /storage|presign|S3/i.test(message);
    const databaseError = /database/i.test(message);
    if (storageError) console.error("[Shorts] Durable clip storage failed.");
    const userMessage = storageError ? "ClipForge could not save the rendered Shorts to durable project storage. Please try again shortly." : message;
    const status = storageError || databaseError ? 503 : /ffprobe|not contain a readable video/i.test(message) ? 422 : /200 MB|exceeds|upload limit/i.test(message) ? 413 : 400;
    jsonError(res, status, userMessage);
  } finally {
    await rm(workDirectory, { recursive: true, force: true });
  }
}
