import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { analyzeVideo, validateVideoUrl } from "./analysis";
import { updateCandidateStatus } from "./db";

const musicMoodSchema = z.enum(["none", "cinematic", "upbeat", "lofi", "energetic", "motivational"]);
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  analysis: router({
    run: publicProcedure
      .input(z.object({
        url: z.string().min(1).max(2048),
        editDescription: z.string().max(1000).default(""),
        musicMood: musicMoodSchema.default("none"),
        transcript: z.string().max(60000).optional(),
      }))
      .mutation(async ({ input }) => {
        if (!validateVideoUrl(input.url)) {
          throw new Error("Use a public YouTube video link (youtube.com or youtu.be).");
        }
        return analyzeVideo({ ...input, clipCount: 6 });
      }),
    reviewCandidate: publicProcedure
      .input(z.object({
        projectId: z.string().uuid(),
        candidateId: z.string().uuid(),
        status: z.enum(["approved", "dismissed"]),
      }))
      .mutation(async ({ input }) => {
        const updated = await updateCandidateStatus(input.projectId, input.candidateId, input.status);
        if (!updated) throw new Error("This clip could not be found in the current analysis. Analyze the source again and retry.");
        return { success: true } as const;
      }),
  }),
});

export type AppRouter = typeof appRouter;
