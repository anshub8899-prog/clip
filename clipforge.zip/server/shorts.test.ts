import { describe, expect, it } from "vitest";
import { validateShortCuts } from "./shorts";

const validCuts = [
  { id: "clip-1", title: "Strong opening", startSeconds: 10, endSeconds: 35 },
  { id: "clip-2", title: "Useful takeaway", startSeconds: 50, endSeconds: 80 },
];

describe("Shorts cut validation", () => {
  it("accepts approved individual cuts within source bounds", () => {
    expect(validateShortCuts(validCuts, 120)).toEqual(validCuts);
  });

  it("rejects cuts outside the uploaded source duration", () => {
    expect(() => validateShortCuts([{ ...validCuts[0], endSeconds: 130 }], 120)).toThrow(/outside the source video/);
  });

  it("rejects overlapping cuts so each Short remains a distinct moment", () => {
    expect(() => validateShortCuts([
      validCuts[0],
      { ...validCuts[1], startSeconds: 30, endSeconds: 60 },
    ], 120)).toThrow(/overlap/);
  });

  it("requires one to eight valid Shorts and enforces the supported duration", () => {
    expect(() => validateShortCuts([], 120)).toThrow(/between one and eight/);
    expect(() => validateShortCuts([{ ...validCuts[0], endSeconds: 200 }], 300)).toThrow(/supported cut range/);
    expect(() => validateShortCuts(Array.from({ length: 7 }, (_, index) => ({
      id: `clip-${index}`,
      title: "A separate short",
      startSeconds: index * 20,
      endSeconds: index * 20 + 10,
    })), 300)).toThrow(/between one and eight/);
  });
});
