import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowDownToLine,
  ArrowUpRight,
  Check,
  Clock3,
  ExternalLink,
  Film,
  Filter,
  Link2,
  Music2,
  RefreshCw,
  ScanSearch,
  Scissors,
  Sparkles,
  ThumbsDown,
  ThumbsUp,
  TriangleAlert,
  X,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

type Candidate = {
  id: string;
  rank: number;
  title: string;
  description: string;
  hook: string;
  rationale: string;
  editNotes: string;
  startSeconds: number;
  endSeconds: number;
  score: number;
  status: "new" | "approved" | "dismissed";
};

type MusicMood = "none" | "cinematic" | "upbeat" | "lofi" | "energetic" | "motivational";
type AnalysisResult = {
  projectId: string;
  sourceUrl: string;
  sourceVideoId: string;
  sourceTitle: string;
  durationSeconds: number;
  resultOrigin: "live";
  transcriptSource: "youtube-captions" | "user-provided" | "audio-transcription" | "direct-video-analysis";
  editDescription: string;
  musicMood: MusicMood;
  candidates: Candidate[];
};
type RenderedClip = {
  id: string;
  title: string;
  startSeconds: number;
  endSeconds: number;
  url: string;
  downloadUrl: string;
  sourceTitle?: string;
  sourceVideoId?: string;
  createdAt?: number;
};

const stages = [
  { label: "Checking the YouTube source", icon: Link2 },
  { label: "Reading captions or video media", icon: ScanSearch },
  { label: "Finding clip-worthy moments", icon: Activity },
  { label: "Building your edit plan", icon: Scissors },
];
const musicLabels: Record<MusicMood, string> = {
  none: "No added music",
  cinematic: "Cinematic",
  upbeat: "Upbeat pop",
  lofi: "Lo-fi chill",
  energetic: "High energy",
  motivational: "Motivational",
};
const analysisSourceLabels = {
  "youtube-captions": "YouTube captions",
  "user-provided": "Transcript you supplied",
  "audio-transcription": "Automatically transcribed audio",
  "direct-video-analysis": "Direct video analysis",
} as const;

const SAVED_CLIPS_KEY = "clipforge.saved-shorts.v1";

function loadSavedClips(): RenderedClip[] {
  if (typeof window === "undefined") return [];
  try {
    const saved: unknown = JSON.parse(window.localStorage.getItem(SAVED_CLIPS_KEY) ?? "[]");
    if (!Array.isArray(saved)) return [];
    return saved.filter((item): item is RenderedClip => {
      if (!item || typeof item !== "object") return false;
      const clip = item as Partial<RenderedClip>;
      const isAssetPath = (value: unknown) => typeof value === "string" && value.startsWith("/manus-storage/") && !value.includes("..") && value.length < 1024;
      return typeof clip.id === "string" && typeof clip.title === "string" && Number.isFinite(clip.startSeconds) && Number.isFinite(clip.endSeconds) && isAssetPath(clip.url) && clip.url === clip.downloadUrl;
    }).slice(0, 24);
  } catch {
    return [];
  }
}

function formatTime(totalSeconds: number) {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const hours = Math.floor(safe / 3600);
  const minutes = Math.floor((safe % 3600) / 60).toString().padStart(2, "0");
  const seconds = (safe % 60).toString().padStart(2, "0");
  return hours > 0 ? `${hours}:${minutes}:${seconds}` : `${minutes}:${seconds}`;
}

function formatDuration(startSeconds: number, endSeconds: number) {
  return `${Math.max(1, endSeconds - startSeconds)}s`;
}

function hostFor(url: string) {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return "YouTube"; }
}

function ScoreBadge({ score }: { score: number }) {
  return <div className="score-badge" aria-label={`${score} percent potential`}><span>{score}</span><small>%</small></div>;
}

export default function Home() {
  const [url, setUrl] = useState("");
  const [editDescription, setEditDescription] = useState("Vertical 9:16 shorts, tight pacing, accurate on-screen captions, open with the strongest hook.");
  const [musicMood, setMusicMood] = useState<MusicMood>("upbeat");
  const [transcript, setTranscript] = useState("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [showOnlyNew, setShowOnlyNew] = useState(false);
  const [phase, setPhase] = useState(0);
  const [localError, setLocalError] = useState("");
  const [notice, setNotice] = useState("");
  const [reviewState, setReviewState] = useState<Record<string, Candidate["status"]>>({});
  const [sourceVideoFile, setSourceVideoFile] = useState<File | null>(null);
  const [rightsConfirmed, setRightsConfirmed] = useState(false);
  const [isRendering, setIsRendering] = useState(false);
  const [renderedClips, setRenderedClips] = useState<RenderedClip[]>(loadSavedClips);

  const analysisMutation = trpc.analysis.run.useMutation({
    onSuccess: data => {
      const next = data as AnalysisResult;
      setResult(next);
      setSelectedId(next.candidates[0]?.id ?? null);
      setReviewState(Object.fromEntries(next.candidates.map(candidate => [candidate.id, "approved"] as const)));
      setPhase(0);
      setNotice("");
    },
    onError: error => {
      const message = error.message || "We could not analyze that link.";
      setLocalError(/usage\s*exhausted|exhausted\s+(?:the\s+)?(?:usage|quota)|412\s+precondition/i.test(message)
        ? "ClipForge AI analysis is temporarily unavailable because this workspace has exhausted its model usage. No clip suggestions were created. Restore AI usage or try again later."
        : message);
      setPhase(0);
    },
  });
  const reviewMutation = trpc.analysis.reviewCandidate.useMutation();

  useEffect(() => {
    if (!analysisMutation.isPending) return;
    const timer = window.setInterval(() => setPhase(current => Math.min(current + 1, stages.length - 1)), 1250);
    return () => window.clearInterval(timer);
  }, [analysisMutation.isPending]);

  useEffect(() => {
    try {
      window.localStorage.setItem(SAVED_CLIPS_KEY, JSON.stringify(renderedClips.slice(0, 24)));
    } catch {
      // Durable MP4 assets remain in project storage even when browser storage is unavailable.
    }
  }, [renderedClips]);

  const candidates = useMemo(() => {
    if (!result) return [];
    return result.candidates.filter(candidate => {
      const status = reviewState[candidate.id] ?? candidate.status;
      const matchesQuery = `${candidate.title} ${candidate.description} ${candidate.hook}`.toLowerCase().includes(query.toLowerCase());
      return matchesQuery && (!showOnlyNew || status === "new");
    });
  }, [result, query, reviewState, showOnlyNew]);
  const selected = result?.candidates.find(candidate => candidate.id === selectedId) ?? result?.candidates[0];
  const renderClipIds = result?.candidates.filter(candidate => (reviewState[candidate.id] ?? candidate.status) === "approved").map(candidate => candidate.id) ?? [];

  function submitAnalysis(event: React.FormEvent) {
    event.preventDefault();
    setLocalError("");
    setNotice("");
    setSourceVideoFile(null);
    setRightsConfirmed(false);
    if (!/^https?:\/\/(?:www\.|m\.)?(?:youtube\.com|youtu\.be)\//i.test(url.trim())) {
      setLocalError("Paste a public YouTube video link (youtube.com or youtu.be).");
      return;
    }
    setResult(null);
    setSelectedId(null);
    setPhase(0);
    analysisMutation.mutate({
      url: url.trim(),
      editDescription: editDescription.trim(),
      musicMood,
      ...(transcript.trim() ? { transcript: transcript.trim() } : {}),
    });
  }

  async function setStatus(candidateId: string, status: Candidate["status"]) {
    if (!result || status === "new") return;
    const previous = reviewState[candidateId] ?? result.candidates.find(candidate => candidate.id === candidateId)?.status ?? "new";
    setReviewState(current => ({ ...current, [candidateId]: status }));
    setLocalError("");
    try {
      await reviewMutation.mutateAsync({ projectId: result.projectId, candidateId, status });
    } catch (error) {
      setReviewState(current => ({ ...current, [candidateId]: previous }));
      setLocalError(error instanceof Error ? error.message : "ClipForge could not save that review decision. Try again.");
    }
  }

  async function requestRender() {
    setLocalError("");
    if (!result) return;
    if (!result.durationSeconds) {
      setLocalError("The source duration could not be verified, so ClipForge cannot safely check the uploaded file. Analyze a link with available video details and retry.");
      return;
    }
    if (!renderClipIds.length) {
      setLocalError("All discovered clips were dismissed. Run the analysis again to create Shorts.");
      return;
    }
    if (!sourceVideoFile) {
      setLocalError("Upload the matching source video file you own or are authorized to edit.");
      return;
    }
    if (sourceVideoFile.size > 200 * 1024 * 1024) {
      setLocalError("The source video exceeds the 200 MB upload limit.");
      return;
    }
    if (!rightsConfirmed) {
      setLocalError("Confirm that you own or are authorized to edit this source video.");
      return;
    }
    const form = new FormData();
    form.append("sourceVideo", sourceVideoFile);
    form.append("rightsConfirmed", "true");
    form.append("projectId", result.projectId);
    form.append("candidateIds", JSON.stringify(renderClipIds));
    setIsRendering(true);
    try {
      const response = await fetch("/api/shorts/render", { method: "POST", body: form });
      const data = await response.json().catch(() => ({})) as { error?: string; clips?: RenderedClip[]; metadataIndexed?: boolean; warning?: string };
      if (!response.ok) throw new Error(data.error || "The Shorts could not be rendered.");
      const clips = Array.isArray(data.clips) ? data.clips.map(clip => ({ ...clip, sourceTitle: result.sourceTitle, sourceVideoId: result.sourceVideoId, createdAt: Date.now() })) : [];
      if (!clips.length) throw new Error("No Shorts were returned. Approve moments and try again.");
      setRenderedClips(current => [...clips, ...current].slice(0, 24));
      if (data.metadataIndexed === false) {
        setLocalError(data.warning || "The clips were stored, but their history could not be indexed. Download the videos while the issue is resolved.");
      } else {
        setNotice(`${clips.length} vertical short${clips.length === 1 ? " is" : "s are"} ready and saved in durable project storage. This browser keeps the results across refreshes.`);
      }
    } catch (error) {
      setLocalError(error instanceof Error ? error.message : "The Shorts could not be rendered.");
    } finally {
      setIsRendering(false);
    }
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark"><span>C</span><span>F</span></div>
          <div><div className="brand-name">clipforge</div><div className="brand-caption">AI CUT ROOM / 01</div></div>
        </div>
        <div className="topbar-actions">
          <div className="live-indicator"><span className="signal-dot" /> SOURCE-LED ANALYSIS</div>
          <div className="avatar">CF</div>
        </div>
      </header>

      <main className="workspace">
        <aside className="sidebar">
          <div className="eyebrow">NEW ANALYSIS</div>
          <h1>Find the moment<br /><em>before they do.</em></h1>
          <p className="lede">Turn one YouTube video into a ranked set of short-form cut plans. Pick the style, music direction, and number of moments.</p>

          <form className="url-form" onSubmit={submitAnalysis}>
            <label htmlFor="video-url">YOUTUBE VIDEO LINK</label>
            <div className={`url-input-wrap ${localError ? "has-error" : ""}`}>
              <Link2 size={16} />
              <input id="video-url" value={url} onChange={event => setUrl(event.target.value)} placeholder="youtube.com/watch?v=..." autoComplete="url" required />
              {url && <button type="button" className="clear-input" onClick={() => setUrl("")} aria-label="Clear URL"><X size={14} /></button>}
            </div>

            <label className="field-label" htmlFor="edit-description">EDIT DESCRIPTION</label>
            <textarea id="edit-description" className="forge-textarea" value={editDescription} onChange={event => setEditDescription(event.target.value)} maxLength={1000} rows={3} placeholder="Describe pacing, captions, crop, tone…" />

            <label className="field-label" htmlFor="music-mood">MUSIC DIRECTION</label>
            <div className="music-select-wrap"><Music2 size={14} /><select id="music-mood" className="forge-select" value={musicMood} onChange={event => setMusicMood(event.target.value as MusicMood)}>
              {Object.entries(musicLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select></div>
            <p className="field-hint">The music direction is kept as an edit note. Exported Shorts preserve source audio; no extra music track is mixed.</p>

            <details className="transcript-details">
              <summary>Optional: use a timestamped transcript</summary>
              <textarea className="forge-textarea transcript-textarea" value={transcript} onChange={event => setTranscript(event.target.value)} maxLength={60000} rows={5} placeholder="Optional: paste a timestamped transcript, e.g. [02:14] words spoken here…" />
              <small>Only the YouTube link is required. ClipForge checks captions first, then analyzes the linked video directly if captions are unavailable. A transcript is optional.</small>
            </details>
            {localError && <div className="inline-error"><TriangleAlert size={14} /> {localError}</div>}
            <Button type="submit" className="analyze-button" disabled={analysisMutation.isPending || isRendering}>
              {analysisMutation.isPending ? <><RefreshCw size={16} className="spin" /> Finding every moment</> : <><Sparkles size={16} /> Find all clips <ArrowUpRight size={15} /></>}
            </Button>
          </form>

          <div className="sidebar-divider" />
          <div className="how-it-works">
            <div className="eyebrow">THE CUT ROOM</div>
            {stages.map((stage, index) => {
              const Icon = stage.icon;
              const complete = Boolean(result) || (!analysisMutation.isPending && index === 0);
              const active = analysisMutation.isPending && phase === index;
              return <div className={`process-row ${active ? "active" : ""} ${complete ? "complete" : ""}`} key={stage.label}>
                <div className="process-icon">{complete && !active ? <Check size={13} /> : <Icon size={14} />}</div>
                <span>{stage.label}</span>{active && <span className="process-pulse" />}
              </div>;
            })}
          </div>
          <div className="sidebar-footer">
            <div className="credit-card"><Zap size={15} /><span><strong>Editorial workspace</strong><br />Review before you export</span></div>
            <div className="footer-note"><span className="signal-dot small" /> Built for editors who move fast.</div>
          </div>
        </aside>

        <section className="main-canvas">
          {!result && !analysisMutation.isPending && (
            <div className="empty-state">
              <div className="empty-orbit"><div className="orbit-dot one" /><div className="orbit-dot two" /><div className="orbit-dot three" /><Film size={31} /></div>
              <div className="eyebrow">CUT ROOM STANDBY</div>
              <h2>Your next set of shorts<br /><span>starts with the story.</span></h2>
              <p>Paste a public YouTube link—that is all you need. ClipForge checks captions and analyzes the linked video directly when captions are unavailable, then builds a ranked cut plan.</p>
              <div className="empty-chips"><span><Sparkles size={13} /> Video-grounded moments</span><span><Clock3 size={13} /> Timestamped cut plans</span><span><Music2 size={13} /> Music direction</span></div>
              <div className="empty-disclaimer">After reviewing moments, upload the matching source video you are authorized to edit. ClipForge will export only the selected cuts as individual 9:16 Shorts.</div>
            </div>
          )}

          {analysisMutation.isPending && (
            <div className="processing-state">
              <div className="processing-topline"><span><span className="signal-dot" /> SOURCE-GROUNDED ANALYSIS</span><span>{Math.min(92, 20 + phase * 22)}%</span></div>
              <div className="scan-panel"><div className="scan-grid" /><div className="scan-line" /><div className="scan-copy"><div className="scan-glyph"><ScanSearch size={28} /></div><div className="eyebrow">{stages[phase].label.toUpperCase()}</div><h2>Looking for moments<br /><em>the source supports.</em></h2><p>Captions are checked first. If they are missing, ClipForge analyzes the linked video directly and grounds cut times in its media.</p></div></div>
              <div className="processing-steps">{stages.map((stage, index) => <div className={`processing-step ${index <= phase ? "on" : ""}`} key={stage.label}><span>{String(index + 1).padStart(2, "0")}</span><div><strong>{stage.label}</strong><small>{index < phase ? "complete" : index === phase ? "in progress" : "queued"}</small></div></div>)}</div>
            </div>
          )}

          {result && selected && (
            <div className="results-view">
              <div className="results-header">
                <div>
                  <div className="eyebrow">CUT PLAN READY <span className="result-origin">SOURCE-GROUNDED</span></div>
                  <h2>{result.sourceTitle}</h2>
                  <div className="source-meta"><span><Link2 size={13} /> {hostFor(result.sourceUrl)}</span><span>{analysisSourceLabels[result.transcriptSource]}</span><a href={result.sourceUrl} target="_blank" rel="noreferrer">Open source <ExternalLink size={12} /></a></div>
                </div>
                <div className="result-summary"><strong>{result.candidates.length}</strong><span>clip plans<br />ranked</span></div>
              </div>

              <div className="review-grid">
                <div className="preview-column">
                  <div className="section-label"><span>01 / YOUTUBE SOURCE</span><span className="muted-label">JUMP NEAR {formatTime(selected.startSeconds)}</span></div>
                  <div className="video-stage youtube-stage">
                    <iframe key={`${result.sourceVideoId}-${selected.id}`} src={`https://www.youtube-nocookie.com/embed/${result.sourceVideoId}?start=${Math.floor(selected.startSeconds)}&rel=0`} title={`YouTube preview: ${selected.title}`} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen />
                  </div>
                  <div className="timeline-wrap">
                    <div className="timeline-scale"><span>00:00</span><span>{formatTime(Math.round((result.durationSeconds || selected.endSeconds) / 3))}</span><span>{formatTime(Math.round((result.durationSeconds || selected.endSeconds) * 2 / 3))}</span><span>{formatTime(result.durationSeconds || selected.endSeconds)}</span></div>
                    <div className="timeline">
                      <div className="timeline-fill" />
                      <div className="timeline-marker" style={{ left: `${Math.min(98, (selected.startSeconds / Math.max(result.durationSeconds, selected.endSeconds)) * 100)}%` }}><span /></div>
                      {result.candidates.map((candidate, index) => {
                        const duration = Math.max(result.durationSeconds, candidate.endSeconds, 1);
                        return <button key={candidate.id} aria-label={`Select ${candidate.title}`} title={`${formatTime(candidate.startSeconds)} — ${formatTime(candidate.endSeconds)}`} className={`timeline-segment segment-${index + 1} ${candidate.id === selected.id ? "selected" : ""}`} onClick={() => setSelectedId(candidate.id)} style={{ left: `${(candidate.startSeconds / duration) * 100}%`, width: `${Math.max(2.5, ((candidate.endSeconds - candidate.startSeconds) / duration) * 100)}%` }} />;
                      })}
                    </div>
                    <div className="timeline-legend"><span><i className="legend-selected" /> selected cut</span><span><i className="legend-opportunity" /> clip opportunities</span></div>
                  </div>
                  <div className="selected-detail">
                    <div className="detail-number">{String(selected.rank).padStart(2, "0")}</div>
                    <div><div className="eyebrow">{formatTime(selected.startSeconds)} — {formatTime(selected.endSeconds)} / {formatDuration(selected.startSeconds, selected.endSeconds)}</div><h3>{selected.title}</h3><p>{selected.description}</p><p className="hook-line"><strong>Opening hook</strong> {selected.hook}</p><p className="edit-notes-line"><strong>Edit notes</strong> {selected.editNotes}</p></div>
                  </div>
                </div>

                <aside className="opportunity-column">
                  <div className="section-label"><span>02 / CLIP OPPORTUNITIES</span><span className="count-label">{candidates.length} shown</span></div>
                  <div className="filter-bar"><div className="search-mini"><ScanSearch size={14} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search cut list" /></div><button className={`filter-button ${showOnlyNew ? "active" : ""}`} onClick={() => setShowOnlyNew(current => !current)}><Filter size={14} /> {showOnlyNew ? "New only" : "Filter"}</button></div>
                  <div className="candidate-list">{candidates.map(candidate => {
                    const status = reviewState[candidate.id] ?? candidate.status;
                    return <button key={candidate.id} className={`candidate-card ${candidate.id === selected.id ? "selected" : ""} ${status}`} onClick={() => setSelectedId(candidate.id)}>
                      <div className="candidate-top"><span className="candidate-rank">{String(candidate.rank).padStart(2, "0")}</span><span className="candidate-time"><Clock3 size={12} /> {formatTime(candidate.startSeconds)} — {formatTime(candidate.endSeconds)}</span><ScoreBadge score={candidate.score} /></div>
                      <h3>{candidate.title}</h3><p>{candidate.description}</p>
                      <div className="candidate-footer"><span className="candidate-status">{status === "approved" ? <><Check size={12} /> Approved</> : status === "dismissed" ? <><X size={12} /> Dismissed</> : <><Sparkles size={12} /> Review</>}</span><span className="open-detail">Inspect <ArrowUpRight size={13} /></span></div>
                    </button>;
                  })}</div>
                  {!candidates.length && <div className="no-candidates">No clips match that filter.</div>}
                  <div className="review-actions"><div><div className="eyebrow">03 / OPTIONAL REVIEW</div><p>Every grounded moment is ready automatically. Dismiss any clip you do not want to export.</p></div><div className="action-buttons"><Button size="sm" variant="outline" disabled={reviewMutation.isPending} onClick={() => void setStatus(selected.id, "dismissed")}><ThumbsDown size={14} /> Dismiss</Button><Button size="sm" className="approve-button" disabled={reviewMutation.isPending} onClick={() => void setStatus(selected.id, "approved")}><ThumbsUp size={14} /> Keep clip</Button></div></div>
                </aside>
              </div>

              <div className="music-plan-strip"><Music2 size={16} /><div><strong>Sound direction · {musicLabels[result.musicMood]}</strong><span>The original source audio is retained in each cut. Music direction remains an edit note; no additional track is mixed.</span></div><span className="format-tag">9:16 · MP4</span></div>
              <div className="analysis-note"><Sparkles size={14} /><span><strong>Your edit brief</strong> {result.editDescription || "Default short-form edit"}<br /><strong>Analysis source</strong> {analysisSourceLabels[result.transcriptSource]}. ClipForge found every grounded moment it could identify; dismiss any you do not want before rendering.</span></div>
              <div className="render-panel">
                <div className="render-panel-heading"><div><div className="eyebrow">04 / CREATE ALL YOUR SHORTS</div><p>Upload the matching source file. ClipForge automatically cuts every grounded moment it found into individual vertical 9:16 videos (1080 × 1920).</p></div><span className="upload-limit">MAX 200 MB</span></div>
                <label className="upload-field" htmlFor="shorts-source-video"><Film size={17} /><span><strong>{sourceVideoFile?.name || "Choose source video"}</strong><small>{sourceVideoFile ? `${(sourceVideoFile.size / (1024 * 1024)).toFixed(1)} MB · ${sourceVideoFile.type || "video"}` : "MP4, MOV, WebM, or another supported video · must match the analyzed source"}</small></span><span className="choose-file">Browse</span></label>
                <input id="shorts-source-video" className="visually-hidden-file" type="file" accept="video/*" onChange={event => { setSourceVideoFile(event.currentTarget.files?.[0] ?? null); setLocalError(""); setNotice(""); }} />
                <label className="rights-confirm"><input type="checkbox" checked={rightsConfirmed} onChange={event => setRightsConfirmed(event.target.checked)} /><span>I own this video or am authorized to edit and create clips from it.</span></label>
                {!result.durationSeconds && <div className="inline-error"><TriangleAlert size={14} /> The source duration is unavailable, so ClipForge cannot verify the matching upload. Try a link with available video details.</div>}
                <div className="render-actions"><div><div className="eyebrow">CLIP-ONLY OUTPUT</div><p>Only grounded time ranges from this source become individual MP4 files. The full source video is never returned. Finished clips are stored durably.</p></div><Button className="approve-button render-button" onClick={requestRender} disabled={isRendering || analysisMutation.isPending || reviewMutation.isPending || !renderClipIds.length || !result.durationSeconds}>{isRendering ? <><RefreshCw size={14} className="spin" /> Cutting all clips</> : <><Scissors size={14} /> Create all Shorts</>}</Button></div>
              </div>
              {localError && <div className="inline-error result-error"><TriangleAlert size={14} /> {localError}</div>}
              {notice && <div className="render-notice"><Check size={15} /> {notice}</div>}
              <div className="rights-note">Source analysis uses the public YouTube link; actual files are cut only from the video you upload. ClipForge does not download the YouTube source.</div>
            </div>
          )}
          {renderedClips.length > 0 && <section className="shorts-results" aria-label="Rendered vertical Shorts"><div className="shorts-results-heading"><div><div className="eyebrow">YOUR CUT CLIPS</div><h3>Vertical Shorts ready</h3></div><span>{renderedClips.length} MP4 · 9:16 · SAVED</span></div><div className="shorts-grid">{renderedClips.map((clip, index) => <article className="short-card" key={`${clip.id}-${clip.createdAt ?? index}`}><div className="short-video-frame"><video controls playsInline preload="metadata" src={clip.url} aria-label={`Preview of ${clip.title}`} /></div><div className="short-card-info"><span className="eyebrow">SHORT {String(index + 1).padStart(2, "0")} · {formatTime(clip.startSeconds)}–{formatTime(clip.endSeconds)}</span><h4>{clip.title}</h4>{clip.sourceTitle && <p className="short-source-title">From {clip.sourceTitle}</p>}<a className="download-short" href={clip.downloadUrl} download={`clip-${String(index + 1).padStart(2, "0")}.mp4`} aria-label={`Download ${clip.title} as MP4`}><ArrowDownToLine size={14} /> Download clip</a></div></article>)}</div></section>}
        </section>
      </main>
    </div>
  );
}
