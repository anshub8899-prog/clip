# ClipForge AI — outcome tracker

## Source-led AI moment analysis
- [x] The user can submit a public YouTube video URL and optionally provide a timestamped transcript; ClipForge checks captions/available source details, and can attempt direct-video analysis when captions are unavailable.
- [x] Clip suggestions are grounded in supplied captions, transcript, or accessible video content and include a title, exact source timestamps, concise rationale/context, and score; inaccessible media does not yield fabricated suggestions.
- [x] Analysis provides clear loading/progress, empty, invalid-link, inaccessible-media, and recoverable failure states.
- [x] LLM usage exhaustion produces a plain-language explanation, does not retry a non-transient quota failure repeatedly, and offers actionable retry guidance without exposing a raw stack trace.

**Live-analysis limitation:** this project's model usage is currently exhausted (412). The code and regression tests are in place, but a successful live model response cannot be verified until workspace usage is restored.

## Review and select moments
- [x] The user can inspect the source and suggestions, preview a suggested timestamp, and review each title, timestamp, rationale/context, and score.
- [x] The user can approve or dismiss individual moments; these decisions are persisted server-side. Rendering accepts only approved candidate IDs belonging to that saved analysis; server-loaded titles and timestamps are used instead of caller-supplied cut data.

## Authorized source cutting
- [x] To render, the user uploads a source video they own or are authorized to edit and explicitly confirms that authorization; the application does not download source videos from YouTube.
- [x] The render request is bound server-side to the saved YouTube source. Uploads are limited to 200 MB, validated with `ffprobe`, require a known stored source duration, and are rejected when the uploaded duration differs by more than three seconds.
- [x] Each remaining approved moment is cut into its own MP4 with source audio retained when present, center-cropped to exactly 1080×1920 (9:16); no full source video is returned as a clip.
- [x] Source uploads and temporary render files are deleted after processing; generated MP4s are stored under stable project-storage paths and clip metadata is indexed in the project database. If that index write fails after rendering, the response and UI explicitly warn while keeping clips playable/downloadable.

**Identity limitation:** because the app does not download YouTube media, it cannot fingerprint the uploaded file to prove its content is identical to the video at the saved source URL. The source ID and duration are checked, and the user's confirmation remains necessary.

## Shorts results and persistent Preview
- [x] The results view contains only generated vertical clips, with an embedded player and an individual download action for every clip; the browser retains up to 24 recent result references through refreshes.
- [x] The ClipForge app runs in the managed stable Preview with the selected Signal Room design (near-black editor surfaces, electric-blue signals, compact IBM Plex Sans typography); the project is not publicly published unless explicitly requested.
